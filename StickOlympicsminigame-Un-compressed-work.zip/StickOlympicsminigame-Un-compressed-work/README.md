# StickOlympicsminigame
My first game. For some University Coursework
